package org.koin.sampleapp.repository.data.weather

import com.google.gson.annotations.Expose

class SnowAllday {

    /**
     * @return The in
     */
    /**
     * @param in The in
     */
    @Expose
    var `in`: Double? = null
    /**
     * @return The cm
     */
    /**
     * @param cm The cm
     */
    @Expose
    var cm: Double? = null

}
