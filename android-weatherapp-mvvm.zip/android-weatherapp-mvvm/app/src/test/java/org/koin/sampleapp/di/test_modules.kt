package org.koin.sampleapp.di

import org.koin.dsl.module
import org.koin.sampleapp.datasource.JavaReader
import org.koin.sampleapp.repository.WeatherDatasource
import org.koin.sampleapp.repository.local.LocalDataSource
import org.koin.sampleapp.util.TestSchedulerProvider
import org.koin.sampleapp.util.rx.SchedulerProvider

val localJavaDatasourceModule = module {
    factory { LocalDataSource(JavaReader()) as WeatherDatasource }
}

val testRxModule = module {
    // provided components
    factory { TestSchedulerProvider() as SchedulerProvider }
}

val testApp = weatherApp + testRxModule + localJavaDatasourceModule